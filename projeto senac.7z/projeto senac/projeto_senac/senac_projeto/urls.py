from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login, name='login'),  # URL para a página de login
    path('cadastro/', views.cadastro, name='cadastro'),  # URL para a página de cadastro
    path('historico/', views.historico, name='historico'),
]
