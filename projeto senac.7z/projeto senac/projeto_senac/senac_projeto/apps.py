from django.apps import AppConfig


class SenacProjetoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'senac_projeto'
